package com.example.luisfelipe.popularmovies.database;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

public class MovieContentProvider extends ContentProvider {

    public static final int MOVIES = 10;
    public static final int SINGLE_MOVIE_ID = 9;
    public static final int SINGLE_MOVIE_TITLE = 8;
    public static UriMatcher mUriMatcher = buildUriMatcher();

    public static UriMatcher buildUriMatcher(){
        UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

        //para todos os filmes (favoritos)
        uriMatcher.addURI(MovieDbContract.AUTORITY, MovieDbContract.FavoriteMovies.TABLE_NAME, MOVIES);

        //reconhece qualquer inteiro apos a barra
        uriMatcher.addURI(MovieDbContract.AUTORITY, MovieDbContract.FavoriteMovies.TABLE_NAME + "/#", SINGLE_MOVIE_ID);

        //somente o filme com o titulo enviado
        uriMatcher.addURI(MovieDbContract.AUTORITY, MovieDbContract.FavoriteMovies.TABLE_NAME + "/*", SINGLE_MOVIE_TITLE);
        return uriMatcher;
    }

    private MovieDbHelper movieDb;


    @Override
    public boolean onCreate() {
        Context context = getContext();
        movieDb = new MovieDbHelper(context);
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        SQLiteDatabase db = movieDb.getReadableDatabase();
        int match = mUriMatcher.match(uri);

        Cursor resposta;

        switch (match){
            case MOVIES:
                resposta = db.query(MovieDbContract.FavoriteMovies.TABLE_NAME,
                        projection, selection, selectionArgs, null, null,
                        sortOrder);
                break;
            case SINGLE_MOVIE_ID:
                //pega o id da uri, insere manualmente na query
                //URI: content//<autority>/table/2
                String id = uri.getPathSegments().get(1);
                String mSelection = "_id?";
                String[] mSelectionArgs = new String[]{id};

                resposta = db.query(MovieDbContract.FavoriteMovies.TABLE_NAME, projection,
                        mSelection, mSelectionArgs, null, null, sortOrder);
                break;
            case SINGLE_MOVIE_TITLE:
                //pega o titulo
                String title = uri.getPathSegments().get(1);
                String mSelectionTitle = MovieDbContract.FavoriteMovies.COLUMN_MOVIE_TITLE + "=?";
                Log.d("SelectionTitle", mSelectionTitle);
                String[] mSelectionArgsTitle = new String[]{title};

                resposta = db.query(MovieDbContract.FavoriteMovies.TABLE_NAME, projection, mSelectionTitle,
                        mSelectionArgsTitle, null, null, sortOrder);
                break;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }

        resposta.setNotificationUri(getContext().getContentResolver(), uri);
        return resposta;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        Log.d("CONTENT_PROVIDER", "INSERT");

        SQLiteDatabase db = movieDb.getWritableDatabase();

        int match = mUriMatcher.match(uri);

        Uri resposta;

        switch (match){
            case MOVIES:
                long id = db.insert(MovieDbContract.FavoriteMovies.TABLE_NAME, null, values);
                if(id > 0){
                    //devolve uma uri com o novo id apendado
                    resposta = ContentUris.withAppendedId(MovieDbContract.FavoriteMovies.CONTENT_URI, id);
                }else{
                    throw new android.database.SQLException("Faile to insert row into " + uri);
                }
                break;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }

        //notifica a mudança
        getContext().getContentResolver().notifyChange(uri, null);
        return resposta;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = movieDb.getWritableDatabase();

        int match = mUriMatcher.match(uri);

        int resposta = 0;

        switch(match){
            case SINGLE_MOVIE_ID:
                String id = uri.getPathSegments().get(1);
                String mSelection = "_id?";
                String[] mSelectionArgs = new String[]{id};

                resposta = db.delete(MovieDbContract.FavoriteMovies.TABLE_NAME, mSelection, mSelectionArgs);
                break;
            case SINGLE_MOVIE_TITLE:
                String title = uri.getPathSegments().get(1);
                String mSelectionTitle = MovieDbContract.FavoriteMovies.COLUMN_MOVIE_TITLE + " = ?";
                String[] mSelectionArgsTitle = new String[]{title};

                resposta = db.delete(MovieDbContract.FavoriteMovies.TABLE_NAME, mSelectionTitle, mSelectionArgsTitle);
                break;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);
        return resposta;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

}
