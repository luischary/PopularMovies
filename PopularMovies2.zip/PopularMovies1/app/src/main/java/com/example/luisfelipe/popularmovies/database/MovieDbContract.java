package com.example.luisfelipe.popularmovies.database;

import android.net.Uri;
import android.provider.BaseColumns;

public class MovieDbContract {
    public static final String AUTORITY = "com.example.luisfelipe.popularmovies";
    private MovieDbContract(){};

    //Base Columns insere _ID automaticamente no db
    public static class FavoriteMovies implements BaseColumns{
        public static final String TABLE_NAME="favoriteMovies";
        public static final String COLUMN_MOVIE_ID = "movie_id";
        public static final String COLUMN_MOVIE_TITLE = "movie_title";
        public static final Uri CONTENT_URI = Uri.parse("content://" + AUTORITY + "/" + TABLE_NAME);
    }
}
