package com.example.luisfelipe.popularmovies;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.luisfelipe.popularmovies.database.MovieDbContract;
import com.example.luisfelipe.popularmovies.utils.ApiHandler;
import com.example.luisfelipe.popularmovies.utils.NetworkUtils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MovieDetail extends AppCompatActivity {

    TextView tvTitle;
    TextView tvSinopsis;
    TextView tvReleaseDate;
    TextView tvAverageVote;
    ImageView imMoviePoster;
    TextView tvAvaliacoes;
    TextView tvTrailers;

    int movieId;

    Menu mMenu;
    boolean favorito = false; //inicializa com um não favorito

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("OnCreate", "Iniciando o OnCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        tvTitle = findViewById(R.id.tv_titulo_detalhe);
        tvSinopsis = findViewById(R.id.tv_sinopse_detalhe);
        tvAverageVote = findViewById(R.id.tv_avaliacao_detalhe);
        tvReleaseDate = findViewById(R.id.tv_lancamento_detalhe);
        imMoviePoster = findViewById(R.id.iv_poster_detail);
        tvAvaliacoes = findViewById(R.id.tv_detail_reviews);
        tvTrailers = findViewById(R.id.tv_detail_trailers);

        Intent intent = getIntent();
        if(intent.hasExtra(Intent.EXTRA_CHOSEN_COMPONENT)){
            ApiHandler.Filme mFilme = (ApiHandler.Filme) intent.getSerializableExtra(Intent.EXTRA_CHOSEN_COMPONENT);

            tvTitle.setText(mFilme.getmTitulo());
            tvSinopsis.setText(mFilme.getmSinopse());
            tvAverageVote.setText(String.valueOf(mFilme.getmAvaliacao()));
            tvReleaseDate.setText(mFilme.getDataLancamento());

            movieId = mFilme.getId();

            Picasso.with(this).load(getString(R.string.base_caminho_imagem) + mFilme.getCaminhoImagem()).into(imMoviePoster);

            //carrega os trailers e as avaliações
            new CarregaAvaliacoesTask().execute(getReviewsURL(String.valueOf(mFilme.getId())));
            new GetTrailersTask().execute(movieId);
        }
    }

    public URL getReviewsURL(String movieId){
        Uri uri = Uri.parse(getString(R.string.base_main_url)).buildUpon()
                .appendEncodedPath(movieId)
                .appendPath(getString(R.string.string_reviews))
                .appendQueryParameter(getString(R.string.string_api_key), getString(R.string.api_key))
                .build();

        try {
            return new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public class CarregaAvaliacoesTask extends AsyncTask<URL, Void, String> {

        @Override
        protected String doInBackground(URL... urls) {
            URL url = urls[0];
            String retorno = "";
            try {
                retorno = NetworkUtils.getResponseFromHttpUrl(url);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return retorno;
        }

        @Override
        protected void onPostExecute(String s) {
            if(s != null && !s.equals("")){
                String resposta = "";
                try {
                    resposta = ApiHandler.criaAvaliacoes(new JSONObject(s));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if(resposta != "") {
                    tvAvaliacoes.setText(resposta);
                }else{
                    tvAvaliacoes.setText(R.string.string_sem_avaliacoes);
                }
            }
        }
    }

    public class GetTrailersTask extends AsyncTask<Integer, Void, String>{

        @Override
        protected String doInBackground(Integer... integers) {
            int id = integers[0];
            String resposta = "";

            Uri uri = Uri.parse(getString(R.string.base_url_busca)).buildUpon()
                    .appendPath(String.valueOf(id))
                    .appendPath(getString(R.string.string_videos))
                    .appendQueryParameter(getString(R.string.string_api_key), getString(R.string.api_key))
                    .build();
            Log.d("URI GET_TRAILEFS_TASK",uri.toString());

            try{
                resposta = NetworkUtils.getResponseFromHttpUrl(new URL(uri.toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }

            return resposta;
        }

        @Override
        protected void onPostExecute(String s) {
            List<ApiHandler.Trailer> listaTrailers = new ArrayList<>();

            try {
                listaTrailers = ApiHandler.handleTrailersRequest(new JSONObject(s));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String t = ApiHandler.criaTrailers(listaTrailers, getApplicationContext());
            if(!t.equals(getString(R.string.string_sem_trailers))){
                tvTrailers.setText(Html.fromHtml(t));
                tvTrailers.setMovementMethod(LinkMovementMethod.getInstance());
            }else{
                tvTrailers.setText(t);
            }
        }
    }



    //------------------ FAVORITOS -----------------------------------

    public boolean verificaFilmeFavorito(String titulo){
        Log.d("VerificaFilmeFavorito", "Verifica filme favorito");
        Uri uri = Uri.parse(MovieDbContract.FavoriteMovies.CONTENT_URI + "/" + titulo);
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);

        if(cursor.getCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    public class ChecaFavoritoTask extends AsyncTask<String, Void, Boolean>{

        @Override
        protected Boolean doInBackground(String... strings) {
            String titulo = strings[0];
            boolean resposta = false;
            Log.d("Checa favorito task", "Checa favorito task");
            try{
                resposta = verificaFilmeFavorito(titulo);
            }catch (Exception e){

            }
            return resposta;
        }

        @Override
        protected void onPostExecute(Boolean resposta) {
            atualizaStatusFavorito(resposta);
            favorito = resposta;
        }
    }


    //------------------- MENU FAVORITO ----------------------------------


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.d("CriandoMenu", "Criando o menu de opcoes");
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        mMenu = menu;

        //verifica se é um favorito ou não
        new ChecaFavoritoTask().execute(tvTitle.getText().toString());

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.menu_seleciona_favorito:
                //altera o banco de dados
                new InsereFilmeTask().execute(tvTitle.getText().toString());
                break;
            case R.id.menu_retira_favorito:
                new RemoveFilmeTask().execute(tvTitle.getText().toString());
                break;
        }
        new ChecaFavoritoTask().execute(tvTitle.getText().toString());
        return true;
    }

    public void atualizaStatusFavorito(Boolean favorito){
        Log.d("AtualizaStatusFavorito", "Atualiza status favorito");
        MenuItem selecionaFavorito = mMenu.findItem(R.id.menu_seleciona_favorito);
        MenuItem retiraFavorito = mMenu.findItem(R.id.menu_retira_favorito);
        if(favorito){
            //coloca o icone da estrela cheio
            retiraFavorito.setVisible(true);
            selecionaFavorito.setVisible(false);
        }else{
            retiraFavorito.setVisible(false);
            selecionaFavorito.setVisible(true);
        }

    }

    private class InsereFilmeTask extends AsyncTask<String,Void,Uri>{

        @Override
        protected Uri doInBackground(String... strings) {
            String titulo = strings[0];;
            Uri resposta = null;

            Log.d("InsereFilmeTask", "Insere filme task");
            Log.d("CONTENT URI", MovieDbContract.FavoriteMovies.CONTENT_URI.toString());

            ContentValues valores = new ContentValues();
            valores.put(MovieDbContract.FavoriteMovies.COLUMN_MOVIE_TITLE, titulo);
            valores.put(MovieDbContract.FavoriteMovies.COLUMN_MOVIE_ID, movieId);

            try{
                resposta = getContentResolver().insert(MovieDbContract.FavoriteMovies.CONTENT_URI, valores);
            }catch (Exception e){

            }

            return resposta;
        }

        @Override
        protected void onPostExecute(Uri uri) {
            if(uri == null){
                Toast.makeText(getApplicationContext(), R.string.erro_add_fav, Toast.LENGTH_LONG).show();
            }else {
                Log.d("Resposta do resolver", uri.toString());
                Toast.makeText(getApplicationContext(), tvTitle.getText().toString() + " " +
                        getString(R.string.added_to_favorites), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class RemoveFilmeTask extends AsyncTask<String, Void, Boolean>{

        @Override
        protected Boolean doInBackground(String... strings) {
            String titulo = strings[0];
            int resposta = 0;

            Uri query = Uri.parse(MovieDbContract.FavoriteMovies.CONTENT_URI + "/" + tvTitle.getText().toString());

            try{
                resposta = getContentResolver().delete(query, null, null);
            }catch (Exception e){

            }

            if(resposta > 0)
                return true;
            else
                return false;
        }

        @Override
        protected void onPostExecute(Boolean resposta) {
            if(resposta){
                //Toast.makeText(getApplicationContext(), "Retirado dos favoritos", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getApplicationContext(), R.string.unable_remove_favs, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
