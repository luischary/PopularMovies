package com.example.luisfelipe.popularmovies.loaders;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

import com.example.luisfelipe.popularmovies.utils.ApiHandler;
import com.example.luisfelipe.popularmovies.MainActivity;
import com.example.luisfelipe.popularmovies.utils.NetworkUtils;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;

public class LocalMovieLoader implements LoaderManager.LoaderCallbacks<String> {

    MainActivity mainActivity;

    public LocalMovieLoader(MainActivity m){
        this.mainActivity = m;
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable final Bundle args) {
        return new AsyncTaskLoader<String>(mainActivity.getApplicationContext()) {
            @Override
            protected void onStartLoading() {
                if(args == null){
                    return;
                }
                mainActivity.showLoadingIndicator();
                forceLoad();
            }

            @Nullable
            @Override
            public String loadInBackground() {
                URL url = (URL) args.getSerializable(mainActivity.URL_LOCAL_MOVIE_LOAD);
                String retorno = "";

                try {
                    retorno = NetworkUtils.getResponseFromHttpUrl(url);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return retorno;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        if(!data.equals("") && data != null){
            ApiHandler apiHandler = new ApiHandler();
            try {
                apiHandler.carregaListaFilme(data);
                mainActivity.atualizaListaFilmes(apiHandler.mListaFilme, true);
            } catch (JSONException e) {
                e.printStackTrace();
                mainActivity.atualizaListaFilmes(null, false);
            }
        }else{
            mainActivity.atualizaListaFilmes(null, false);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
