package com.example.luisfelipe.popularmovies.loaders;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

import com.example.luisfelipe.popularmovies.utils.ApiHandler;
import com.example.luisfelipe.popularmovies.MainActivity;
import com.example.luisfelipe.popularmovies.database.MovieDbContract;
import com.example.luisfelipe.popularmovies.R;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class GetFavoritesLoader implements LoaderManager.LoaderCallbacks<Cursor> {

    MainActivity mainActivity;

    public GetFavoritesLoader(MainActivity m){
        this.mainActivity = m;
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(mainActivity.getApplicationContext()) {
            @Override
            protected void onStartLoading() {
                forceLoad();
            }

            @Nullable
            @Override
            public Cursor loadInBackground() {
                Cursor resposta = null;
                try{
                    resposta = mainActivity.getContentResolver().query(MovieDbContract.FavoriteMovies.CONTENT_URI, null,
                            null, null, null);
                }catch (Exception e){
                    e.printStackTrace();
                }

                return resposta;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        if(data != null){
            mainActivity.favoritos = new HashMap<>();
            while(data.moveToNext()){
                ApiHandler.Filme temp = new ApiHandler.Filme();

                temp.setId(data.getInt(data.getColumnIndex(MovieDbContract.FavoriteMovies.COLUMN_MOVIE_ID)));
                temp.setmTitulo(data.getString(data.getColumnIndex(MovieDbContract.FavoriteMovies.COLUMN_MOVIE_TITLE)));

                mainActivity.favoritos.put(temp.getId(), temp);
            }

            //agora busca o restante das informações
            int contagem = 0;
            for (int id :
                    mainActivity.favoritos.keySet()) {
                Uri uri = Uri.parse(mainActivity.getString(R.string.base_url_busca)).buildUpon()
                        .appendPath(String.valueOf(id))
                        .appendQueryParameter(mainActivity.getString(R.string.string_api_key), mainActivity.getString(R.string.api_key))
                        .build();

                try {
                    URL url = new URL(uri.toString());
                    Bundle dados = new Bundle();

                    dados.putString(mainActivity.URL_LOAD_INFO, url.toString());
                    android.support.v4.app.LoaderManager manager = mainActivity.getSupportLoaderManager();
                    Loader<String> mLoader = manager.getLoader(mainActivity.LOADER_FAVS_ID + contagem);

                    if(mLoader == null){
                        manager.initLoader(mainActivity.LOADER_FAVS_ID + contagem, dados, mainActivity.loadFavs);
                    }else{
                        manager.restartLoader(mainActivity.LOADER_FAVS_ID + contagem + 1, dados, mainActivity.loadFavs);
                        contagem = contagem + 1;
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }
}
