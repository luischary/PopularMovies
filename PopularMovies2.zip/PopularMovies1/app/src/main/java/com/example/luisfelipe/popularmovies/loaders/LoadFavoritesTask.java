package com.example.luisfelipe.popularmovies.loaders;

import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.os.Bundle;
import android.support.v4.content.AsyncTaskLoader;

import com.example.luisfelipe.popularmovies.utils.ApiHandler;
import com.example.luisfelipe.popularmovies.MainActivity;
import com.example.luisfelipe.popularmovies.utils.NetworkUtils;

import org.json.JSONException;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


//pesquisa pelo ID e retorna o JSON para tratamento e inclusão do objeto na lista
public class LoadFavoritesTask implements LoaderManager.LoaderCallbacks<String> {

    public static MainActivity mainActivity;

    public LoadFavoritesTask(MainActivity c){
        this.mainActivity = c;
    }



    @Override
    public Loader<String> onCreateLoader(int id, final Bundle args) {
        return new AsyncTaskLoader<String>(mainActivity.getApplicationContext()) {
            @Override
            protected void onStartLoading() {
                if(args == null){
                    return;
                }
                forceLoad();
            }

            @Override
            public String loadInBackground() {
                URL url = null;
                try {
                    url = new URL(args.getString(MainActivity.URL_LOAD_INFO));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                String resposta = "";

                try{
                    resposta = NetworkUtils.getResponseFromHttpUrl(url);
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }

                return resposta;
            }


        };
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data) {
        ApiHandler handler = new ApiHandler();
        try {
            handler.carregaBuscaFilme(data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //substitui os parametros do filme na lista de favoritos
        if(handler.mListaFilme.size() > 0) {
            int id = handler.mListaFilme.get(0).getId();
            String sinopse = handler.mListaFilme.get(0).getmSinopse();
            String caminhoImagem = handler.mListaFilme.get(0).getCaminhoImagem();
            String avaliacoes = handler.mListaFilme.get(0).getAvaliacoes();
            List<ApiHandler.Trailer> trailers = handler.mListaFilme.get(0).getTrailers();
            String dataLancamento = handler.mListaFilme.get(0).getDataLancamento();
            Double avaliacao = handler.mListaFilme.get(0).getmAvaliacao();

            if(mainActivity.favoritos.containsKey(id)) {
                mainActivity.favoritos.get(id).setmSinopse(sinopse);
                mainActivity.favoritos.get(id).setCaminhoImagem(caminhoImagem);
                mainActivity.favoritos.get(id).setAvaliacoes(avaliacoes);
                mainActivity.favoritos.get(id).setTrailers(trailers);
                mainActivity.favoritos.get(id).setDataLancamento(dataLancamento);
                mainActivity.favoritos.get(id).setmAvaliacao(avaliacao);
            }
        }

        if(mainActivity.estadoAtual == mainActivity.LISTA_FAVORITOS){
            mainActivity.atualizaListaFavoritos();
        }

    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }

    /*private MainActivity mActivity;

    public LoadFavoritesTask(MainActivity activity){
        mActivity = activity;
    }
    @Override
    protected String doInBackground(URL... urls) {
        URL url = urls[0];
        String resposta = "";

        try{
            resposta = NetworkUtils.getResponseFromHttpUrl(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return resposta;
    }

    @Override
    protected void onPostExecute(String s) {
        ApiHandler handler = new ApiHandler();
        try {
            handler.carregaBuscaFilme(s);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //substitui os parametros do filme na lista de favoritos
        if(handler.mListaFilme.size() > 0) {
            int id = handler.mListaFilme.get(0).getId();
            String sinopse = handler.mListaFilme.get(0).getmSinopse();
            String caminhoImagem = handler.mListaFilme.get(0).getCaminhoImagem();
            String avaliacoes = handler.mListaFilme.get(0).getAvaliacoes();
            List<ApiHandler.Trailer> trailers = handler.mListaFilme.get(0).getTrailers();
            String dataLancamento = handler.mListaFilme.get(0).getDataLancamento();
            Double avaliacao = handler.mListaFilme.get(0).getmAvaliacao();

            mActivity.favoritos.get(id).setmSinopse(sinopse);
            mActivity.favoritos.get(id).setCaminhoImagem(caminhoImagem);
            mActivity.favoritos.get(id).setAvaliacoes(avaliacoes);
            mActivity.favoritos.get(id).setTrailers(trailers);
            mActivity.favoritos.get(id).setDataLancamento(dataLancamento);
            mActivity.favoritos.get(id).setmAvaliacao(avaliacao);
        }

        if(mActivity.estadoAtual == LISTA_FAVORITOS){
            mActivity.atualizaListaFavoritos();
        }

    }*/
}
