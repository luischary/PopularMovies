package com.example.luisfelipe.popularmovies.utils;

import android.content.Context;
import android.os.Parcelable;

import com.example.luisfelipe.popularmovies.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ApiHandler implements Serializable{

    public List<Filme> mListaFilme;

    public ApiHandler(){
    }

    public void carregaListaFilme(String respostaJSON) throws JSONException {
        mListaFilme = new ArrayList<>();

        JSONObject resposta = new JSONObject(respostaJSON);
        JSONArray resultados = resposta.getJSONArray("results");
        for(int i = 0; i<resultados.length(); i++){
            JSONObject o = (JSONObject) resultados.get(i);
            Filme temp = new Filme();
            temp.setmTitulo(o.getString("title"));
            temp.setmSinopse(o.getString("overview"));
            temp.setCaminhoImagem(o.getString("poster_path"));
            temp.setDataLancamento(o.getString("release_date"));
            temp.setId(o.getInt("id"));
            temp.setmAvaliacao(o.getDouble("vote_average"));

            mListaFilme.add(temp);
        }
    }

    public void carregaBuscaFilme(String respostaJSON) throws JSONException {
        mListaFilme = new ArrayList<>();

        if(respostaJSON != null) {
            JSONObject resposta = new JSONObject(respostaJSON);
            JSONObject resultados = resposta;

            Filme temp = new Filme();
            temp.setId(resultados.getInt("id"));
            temp.setmTitulo(resultados.getString("title"));
            temp.setmSinopse(resultados.getString("overview"));
            temp.setCaminhoImagem(resultados.getString("poster_path"));
            temp.setDataLancamento(resultados.getString("release_date"));
            temp.setmAvaliacao(resultados.getDouble("vote_average"));

            mListaFilme.add(temp);
        }
    }

    public static String criaAvaliacoes(JSONObject avs) throws JSONException {
        String avaliacoesString = "";
        JSONArray mArray = avs.getJSONArray("results");
        for(int i = 0; i < mArray.length(); i++){
            JSONObject objetoAtual = mArray.getJSONObject(i);
            avaliacoesString = avaliacoesString + "\n" + "Autor: " + objetoAtual.getString("author")
                    +   "\n\n" +
                    objetoAtual.getString("content")
                    + "\n\n"
                    + "-------- // ----------";
        }
        return avaliacoesString;
    }

    public static List<Trailer> handleTrailersRequest(JSONObject input) throws JSONException {
        List<Trailer> resposta = new ArrayList<>();
        JSONArray results = input.getJSONArray("results");
        if(results.length() > 0){
            //procura por trailers
            for(int i = 0; i < results.length(); i++){
                JSONObject atual = (JSONObject) results.get(i);
                String tipo = atual.getString("type");
                String site = atual.getString("site");

                if(tipo.equals("Trailer") && site.equals("YouTube")){
                    String chave = atual.getString("key");
                    String nome = atual.getString("name");

                    Trailer t = new Trailer(nome, chave);
                    resposta.add(t);
                }
            }
        }
        return resposta;
    }
    public static String criaTrailers(List<Trailer> lista, Context context){
        String resposta = "";

        if(lista.size() > 0){
            resposta = "<html>";
            for(int i = 0; i < lista.size(); i++){
                Trailer temp = lista.get(i);
                resposta = resposta + "<a href=" + context.getString(R.string.base_trailer_youtube) + "/" + temp.getChave() + ">"
                        + temp.getNome() + "</a>";

                if((lista.size() - i)>1)
                    resposta = resposta + "<br/><br/>";
            }
        }else{
            resposta = context.getString(R.string.string_sem_trailers);
        }

        return resposta;
    }

    public static class Filme implements Serializable {
        int id;
        String mTitulo;
        String caminhoImagem;
        String mSinopse;
        Double mAvaliacao;
        String dataLancamento;
        String avaliacoes;
        List<Trailer> trailers;

        public Filme(){

        }

        public Filme(String mTitulo, String caminhoImagem, String mSinopse, Double mAvaliacao, String dataLancamento, String av, List<Trailer> trailers) {
            this.mTitulo = mTitulo;
            this.caminhoImagem = caminhoImagem;
            this.mSinopse = mSinopse;
            this.mAvaliacao = mAvaliacao;
            this.dataLancamento = dataLancamento;
            this.avaliacoes = av;
            this.trailers = trailers;
        }
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
        public List<Trailer> getTrailers() {
            return trailers;
        }

        public void setTrailers(List<Trailer> trailers) {
            this.trailers = trailers;
        }

        public String getAvaliacoes() {
            return avaliacoes;
        }

        public void setAvaliacoes(String avaliacoes) {
            this.avaliacoes = avaliacoes;
        }

        public String getmTitulo() {
            return mTitulo;
        }

        public void setmTitulo(String mTitulo) {
            this.mTitulo = mTitulo;
        }

        public String getCaminhoImagem() {
            return caminhoImagem;
        }

        public void setCaminhoImagem(String caminhoImagem) {
            this.caminhoImagem = caminhoImagem;
        }

        public String getmSinopse() {
            return mSinopse;
        }

        public void setmSinopse(String mSinopse) {
            this.mSinopse = mSinopse;
        }

        public Double getmAvaliacao() {
            return mAvaliacao;
        }

        public void setmAvaliacao(Double mAvaliacao) {
            this.mAvaliacao = mAvaliacao;
        }

        public String getDataLancamento() {
            return dataLancamento;
        }

        public void setDataLancamento(String dataLancamento) {
            this.dataLancamento = dataLancamento;
        }

    }

    public static class Trailer {
        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getChave() {
            return chave;
        }

        public void setChave(String chave) {
            this.chave = chave;
        }

        String nome;
        String chave;

        public Trailer(String n, String k){
            setNome(n);
            setChave(k);
        }
    }
}
