package com.example.luisfelipe.popularmovies;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.luisfelipe.popularmovies.adapter.MovieAdapter;
import com.example.luisfelipe.popularmovies.loaders.GetFavoritesLoader;
import com.example.luisfelipe.popularmovies.loaders.LoadFavoritesTask;
import com.example.luisfelipe.popularmovies.loaders.LocalMovieLoader;
import com.example.luisfelipe.popularmovies.utils.ApiHandler;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements MovieAdapter.MovieClickListener{

    public static final int LISTA_POPULAR = 1;
    public static final int LISTA_RATING = 2;
    public static final int LISTA_FAVORITOS = 3;

    public static final String URL_LOAD_INFO = "7";
    public static final String URL_LOCAL_MOVIE_LOAD = "url de filmes";

    private static final String STATE_SAVED = "Chave estado salvo";

    public static final int LOADER_FAVS_ID = 400;
    public static final int GET_FAVS_ID = 300;
    public static final int LOCAL_MOVIE_LOAD = 500;

    public LoadFavoritesTask loadFavs;
    public GetFavoritesLoader getFavsLoader;
    public LocalMovieLoader moviesLoader;

    RecyclerView rvMainList;
    ProgressBar progressBar;
    TextView tvError;
    TextView tvSemFavorito;
    public int estadoAtual;
    public Map<Integer,ApiHandler.Filme> favoritos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = (ProgressBar) findViewById(R.id.pb_loading_movies);
        tvError = (TextView) findViewById(R.id.tv_loading_error);
        tvSemFavorito = (TextView) findViewById(R.id.tv_sem_favorito);

        loadFavs = new LoadFavoritesTask(this);
        getFavsLoader = new GetFavoritesLoader(this);
        moviesLoader = new LocalMovieLoader(this);

        rvMainList = (RecyclerView) findViewById(R.id.rv_main_list);
        rvMainList.setLayoutManager(new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false));

        favoritos = new HashMap<>();

        if(savedInstanceState != null){
            if(savedInstanceState.containsKey(STATE_SAVED)){
                int estado = savedInstanceState.getInt(STATE_SAVED);
                setaEstado(estado);
            }
        }else {
            //inicializa com os populares
            setaEstado(LISTA_POPULAR);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        android.support.v4.app.LoaderManager manager = getSupportLoaderManager();
        Loader<Cursor> loader = manager.getLoader(GET_FAVS_ID);
        if(loader == null){
            manager.initLoader(GET_FAVS_ID, null, getFavsLoader);
        }else{
            manager.restartLoader(GET_FAVS_ID, null, getFavsLoader);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SAVED, estadoAtual);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.menu_popular:
                setaEstado(LISTA_POPULAR);
                break;
            case R.id.menu_top_rated:
                setaEstado(LISTA_RATING);
                break;
            case R.id.menu_favoritos:
                setaEstado(LISTA_FAVORITOS);
            default:
                return false;
        }
        return true;
    }

    private void setaEstado(int estado){
        switch (estado){
            case LISTA_FAVORITOS:
                atualizaListaFavoritos();
                estadoAtual = LISTA_FAVORITOS;
                getSupportActionBar().setTitle(R.string.titulo_favoritos);
                break;
            case LISTA_POPULAR:
                Bundle bundle = new Bundle();
                bundle.putSerializable(URL_LOCAL_MOVIE_LOAD, getPopularURL());

                android.support.v4.app.LoaderManager manager = getSupportLoaderManager();
                Loader<String> loader = manager.getLoader(LOCAL_MOVIE_LOAD);
                if(loader == null){
                    manager.initLoader(LOCAL_MOVIE_LOAD, bundle, moviesLoader);
                }else{
                    manager.restartLoader(LOCAL_MOVIE_LOAD, bundle, moviesLoader);
                }
                estadoAtual = LISTA_POPULAR;
                getSupportActionBar().setTitle(R.string.titulo_populares);
                break;
            case LISTA_RATING:
                Bundle bundle2 = new Bundle();
                bundle2.putSerializable(URL_LOCAL_MOVIE_LOAD, getTopRatedURL());

                android.support.v4.app.LoaderManager manager2 = getSupportLoaderManager();
                Loader<String> loader2 = manager2.getLoader(LOCAL_MOVIE_LOAD);
                if(loader2 == null){
                    manager2.initLoader(LOCAL_MOVIE_LOAD, bundle2, moviesLoader);
                }else{
                    manager2.restartLoader(LOCAL_MOVIE_LOAD, bundle2, moviesLoader);
                }
                estadoAtual = LISTA_RATING;
                getSupportActionBar().setTitle(R.string.titulo_melhor_avaliados);
                break;
        }
    }

    public void atualizaListaFavoritos(){
        //transforma o hash em uma lista e popula o adapter com os favoritos
        List<ApiHandler.Filme> listaFav = new ArrayList<>();
        for (int chave :
                favoritos.keySet()) {
            listaFav.add(favoritos.get(chave));
        }
        if(listaFav.size() > 0) {
            atualizaListaFilmes(listaFav, true);
            showMoviesList();
        }else
            showSemFavoritos();
    }

    public void atualizaListaFilmes(List<ApiHandler.Filme> lista, boolean sucesso){
        //se deu certo todo o tramite de atualização da lista de filmes
        if(sucesso){
            MovieAdapter movieAdapter = new MovieAdapter(this, lista, this);
            rvMainList.setAdapter(movieAdapter);
            showMoviesList();
        }else{
            showErrorMessage();
        }
    }

    public URL getTopRatedURL(){
        Uri uri = Uri.parse(getString(R.string.base_main_url)).buildUpon()
                .appendPath(getString(R.string.sort_top_rated))
                .appendQueryParameter(getString(R.string.string_api_key), getString(R.string.api_key))
                .build();

        try {
            return new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public URL getPopularURL(){
        Uri uri = Uri.parse(getString(R.string.base_main_url)).buildUpon()
                .appendPath(getString(R.string.sort_popular))
                .appendQueryParameter(getString(R.string.string_api_key), getString(R.string.api_key))
                .build();

        try {
            return new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void showSemFavoritos(){
        rvMainList.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);
        tvError.setVisibility(View.INVISIBLE);
        tvSemFavorito.setVisibility(View.VISIBLE);
    }
    public void showLoadingIndicator(){
        rvMainList.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        tvError.setVisibility(View.INVISIBLE);
        tvSemFavorito.setVisibility(View.INVISIBLE);
    }

    public void showMoviesList(){
        rvMainList.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.INVISIBLE);
        tvError.setVisibility(View.INVISIBLE);
        tvSemFavorito.setVisibility(View.INVISIBLE);
    }

    public void showErrorMessage(){
        rvMainList.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);
        tvError.setVisibility(View.VISIBLE);
        tvSemFavorito.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onMovieClick(ApiHandler.Filme filme) {
        Intent intent = new Intent(this, MovieDetail.class);
        intent.putExtra(Intent.EXTRA_CHOSEN_COMPONENT, filme);

        startActivity(intent);
    }

}
